﻿using System;
using ClassLib;

namespace LR_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Formula formula = new Formula();
            int cmd;
            double a, b, c, d, r, s, h;

            while (true)
            {
                System.Console.WriteLine("Введите цифрой номер команды:\n1 - Радиус окружности, вписанной в прямоугольный треугольник \n2 - Сумма кубов \n3 - Площадь фигуры через полупериметр и радиус вписанной окружности \n4 - Объем пирамиды \n5 - Площадь основания конуса и цилиндра \n6 - Нахождение дискриминанта \n7 - Средняя линия трапеции \n8 - Формула биссектрисы");
                cmd = int.Parse(Console.ReadLine());

                switch (cmd)
                {
                    case 1:
                        Console.Clear();
                        System.Console.WriteLine("Введите a:");
                        a = double.Parse(Console.ReadLine());
                        System.Console.WriteLine("Введите b:");
                        b = double.Parse(Console.ReadLine());
                        System.Console.WriteLine("Введите c:");
                        c = double.Parse(Console.ReadLine());
                        Console.WriteLine($"Радиус окружности, вписанной в прямоугольный треугольник равен:{formula.CircleInscribed(a,b,c)}\n"); 
                        break;
                    case 2:
                        Console.Clear();
                        System.Console.WriteLine("Введите a:");
                        a = double.Parse(Console.ReadLine());
                        System.Console.WriteLine("Введите b:");
                        b = double.Parse(Console.ReadLine());
                        Console.WriteLine($"Сумма кубов равна:{formula.SumOfCubes(a, b)}\n");
                        break;
                    case 3:
                        Console.Clear();
                        System.Console.WriteLine("Введите a:");
                        a = double.Parse(Console.ReadLine());
                        System.Console.WriteLine("Введите b:");
                        b = double.Parse(Console.ReadLine());
                        System.Console.WriteLine("Введите c:");
                        c = double.Parse(Console.ReadLine());
                        System.Console.WriteLine("Введите r (радиус):");
                        r = double.Parse(Console.ReadLine());
                        Console.WriteLine($"Площадь фигуры через полупериметр и радиус вписанной окружности равна:{formula.AreaOfTheFigure(a, b, c, r)}\n");
                        break;
                    case 4:
                        Console.Clear();
                        System.Console.WriteLine("Введите s:");
                        s = double.Parse(Console.ReadLine());
                        System.Console.WriteLine("Введите h:");
                        h = double.Parse(Console.ReadLine());
                        Console.WriteLine($"Объем пирамиды равен:{formula.PyramidVolume(s, h)}\n");
                        break;
                    case 5:
                        Console.Clear();
                        System.Console.WriteLine("Введите r (радиус):");
                        r = double.Parse(Console.ReadLine());
                        Console.WriteLine($"Площадь основания конуса / цилиндра равна:{formula.AreaOfTheBaseOfTheConeAndCylinder(r)}\n");
                        break;
                    case 6:
                        Console.Clear();
                        System.Console.WriteLine("Введите a:");
                        a = double.Parse(Console.ReadLine());
                        System.Console.WriteLine("Введите b:");
                        b = double.Parse(Console.ReadLine());
                        System.Console.WriteLine("Введите c:");
                        c = double.Parse(Console.ReadLine());
                        Console.WriteLine($"Дискриминант равен:{formula.FindingTheDiscriminant(a,b,c)}\n");
                        break;
                    case 7:
                        Console.Clear();
                        System.Console.WriteLine("Введите a:");
                        a = double.Parse(Console.ReadLine());
                        System.Console.WriteLine("Введите b:");
                        b = double.Parse(Console.ReadLine());
                        Console.WriteLine($"Средняя линия трапеции равна:{formula.TheMiddleLineOfTheTrapezoid(a, b)}\n");
                        break;
                    case 8:
                        Console.Clear();
                        System.Console.WriteLine("Введите a:");
                        a = double.Parse(Console.ReadLine());
                        System.Console.WriteLine("Введите b:");
                        b = double.Parse(Console.ReadLine());
                        System.Console.WriteLine("Введите c:");
                        c = double.Parse(Console.ReadLine());
                        System.Console.WriteLine("Введите d:");
                        d = double.Parse(Console.ReadLine());
                        Console.WriteLine($"Биссектриса равна:{formula.BisectorFormula(a, b, c, d)}\n");
                        break;
                }
            }

        }
    }
}