﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLib
{
    public class Formula
    {
        public double CircleInscribed(double a, double b, double c) //Радиус окружности, вписанной в прямоугольный треугольник
        {
            double radius = (double)(a + b - c) / 2;
            return radius;
        }

        public double SumOfCubes(double a, double b) // Сумма кубов
        {
            double sum = (double)(a + b) * (Math.Pow(a, 2) - a * b + Math.Pow(b, 2));
            return sum;
        }

        public double AreaOfTheFigure(double a, double b, double c, double r) // Площадь фигуры через полупериметр и радиус вписанной окружности
        {
            double area = (double)((a + b + c) / 2) * r;
            return area;
        }

        public double PyramidVolume(double s, double h) // Объем пирамиды
        {
            double volume = (double)(1 / 3) * s * h;
            return volume;
        }

        public double AreaOfTheBaseOfTheConeAndCylinder(double r) // Площадь основания конуса и цилиндра
        {
            double area = (double)Math.PI * Math.Pow(r, 2); // Matn.PI = 3,141592653589793
            return area;
        }

        public double FindingTheDiscriminant(double a, double b, double c) // Нахождение дискриминанта
        {
            double discriminant = (double)Math.Pow(b, 2) - 4 * a * c;
            return discriminant;
        }

        public double TheMiddleLineOfTheTrapezoid(double a, double b) // Средняя линия трапиции
        {
            double middleline = (double)(a + b) / 2;
            return middleline;
        }

        public double BisectorFormula(double a, double b, double c, double d) // Формула биссектрисы
        {
            double bisector = (double)Math.Sqrt(a * b - c * d);
            return bisector;
        }
    }
}
