﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Stack<string> playlist = new Stack<string>();
            int cmd;

            while (true)
            {
                Console.WriteLine("Введите цифрой номер команды: \n1 - Добавить песню \n2 - Посмотреть свой плейлист \n3 - Последняя добавленная песня \n4 - Очистить плейлист");
                cmd = int.Parse(Console.ReadLine());

                switch (cmd)
                {
                    case 1:
                        Console.Clear();
                        Console.WriteLine("Введите исполнителя и название песни (Исполнитель - Название песни): \n");
                        playlist.Push(Console.ReadLine());
                        Console.WriteLine("Песня успешно добавлена в ваш плейлист! \n");
                        break;

                    case 2:
                        Console.Clear();

                        if (playlist.Count > 0)
                        {
                            Console.WriteLine("Ваш плейлист: \n");
                            foreach (string song in playlist)
                            {
                                Console.WriteLine(song);
                            }
                        }
                        else
                        {
                            Console.WriteLine("Плейлист пуст. \n");
                        }
                        Console.WriteLine();

                        break;

                    case 3:
                        Console.Clear();
                        if (playlist.Count > 0)
                        {
                            Console.WriteLine($"Последняя добавленная песня: \n\n{playlist.Peek()}");
                            Console.WriteLine();
                        }
                        else
                        {
                            Console.WriteLine("Плейлист пуст. \n");
                        }
                        break;

                    case 4:
                        Console.Clear();
                        if (playlist.Count > 0)
                        {
                            Console.WriteLine("Выполняется очистка плейлиста...");
                            Thread.Sleep(1000);
                            Console.Clear();
                            playlist.Clear();
                            Console.WriteLine("Плейлист очищен! \n");
                        }
                        else
                        {
                            Console.WriteLine("Плейлист пуст. \n");
                        }
                        break;
                }
            }
        }
    }
}