﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1 
{
    class Program
    {
        static void Main(string[] args)
        {
            Queue<string> recorded = new Queue<string> { };
            int cmd;

            Console.WriteLine("Выберите язык/Choose a language (rus/eng)");
            var language = Console.ReadLine();
            if (language == "rus")
            {
                while (true)
                {
                    System.Console.WriteLine("Введите цифрой номер команды: \n1 - Отобразить очередь записанных на приём \n2 - Принять на приём \n3 - Записать на приём \n");
                    cmd = int.Parse(System.Console.ReadLine());

                    switch (cmd)
                    {
                        case 1:
                            Console.Clear();
                            System.Console.WriteLine();

                            if (recorded.Count > 0)
                            {

                                System.Console.WriteLine("Записанные на приём: \n");

                                foreach (string name in recorded)
                                {

                                    System.Console.WriteLine($"{name}");

                                }
                            }
                            else
                            {
                                System.Console.WriteLine("Очередь пуста!");
                            }

                            System.Console.WriteLine();
                            break;

                        case 2:
                            Console.Clear();
                            System.Console.WriteLine();

                            if (recorded.Count > 0)
                            {
                                recorded.Dequeue();
                                System.Console.WriteLine("На прием принят первый человек из очереди \n");
                            }
                            else
                            {
                                System.Console.WriteLine("Очередь пуста! \n");
                            }
                            break;

                        case 3:
                            Console.Clear();
                            System.Console.WriteLine("Введите ФИО человека для записи на приём: \n");
                            recorded.Enqueue(System.Console.ReadLine());
                            System.Console.WriteLine("Человек успешно записан на приём \n");
                            break;
                    }
                }

            }
            if (language == "eng")
            {
                while (true)
                {
                    System.Console.WriteLine("Enter the command number as a digit: \n1 - Display the queue of appointments \n2 - Accept for an appointment \n3 - Make an appointment \n");
                    cmd = int.Parse(System.Console.ReadLine());

                    switch (cmd)
                    {
                        case 1:
                            Console.Clear();
                            System.Console.WriteLine();

                            if (recorded.Count > 0)
                            {

                                System.Console.WriteLine("Registered for admission: \n");

                                foreach (string name in recorded)
                                {

                                    System.Console.WriteLine($"{name}");

                                }
                            }
                            else
                            {
                                System.Console.WriteLine("Queue is empty!");
                            }

                            System.Console.WriteLine();
                            break;

                        case 2:
                            Console.Clear();
                            System.Console.WriteLine();

                            if (recorded.Count > 0)
                            {
                                recorded.Dequeue();
                                System.Console.WriteLine("First person in line accepted\n");
                            }
                            else
                            {
                                System.Console.WriteLine("Queue is empty! \n");
                            }
                            break;

                        case 3:
                            Console.Clear();
                            System.Console.WriteLine("Enter the FIO of the person to make an appointment: \n");
                            recorded.Enqueue(System.Console.ReadLine());
                            System.Console.WriteLine("The person has been successfully enrolled \n");
                            break;
                    }

                }
            }

        }
    }
}
