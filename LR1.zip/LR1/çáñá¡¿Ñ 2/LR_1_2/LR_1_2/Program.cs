﻿using System;
using System.Collections.Generic;

namespace LR_1_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Stack<string> stack = new Stack<string>();
            int cmd;

            while (true) {
                Console.WriteLine("Введите цифрой номер команды: \n1 - Положить строку в стек \n2 - Посмотреть стек \n3 - Вытащить строку из стека \n");
                cmd = int.Parse(Console.ReadLine());

                switch (cmd)
                {
                    case 1:
                        Console.Clear();
                        Console.WriteLine("Введите строку, которую хотите добавить в стек: \n");
                        stack.Push(Console.ReadLine());
                        Console.WriteLine();
                        break;

                    case 2:
                        Console.Clear();

                        if (stack.Count > 0)
                        {
                            Console.WriteLine("Стек состоит из следующих элементов: \n");
                            foreach (string item in stack)
                            {
                                Console.WriteLine(item);
                            }
                        }
                        else { 
                            Console.WriteLine("Данные отсутствуют.");
                        }
                        Console.WriteLine();

                        break;

                    case 3:
                        Console.Clear();
                        if (stack.Count > 0) {
                            Console.WriteLine($"Вы успешно вытащили строку из стека. Текст этого элемента: \n\n{stack.Pop()}");
                            Console.WriteLine();
                        }
                        else
                        {
                            Console.WriteLine("Данные отсутствуют. \n");
                        }
                        break;
                }
            }
        }
    }
}